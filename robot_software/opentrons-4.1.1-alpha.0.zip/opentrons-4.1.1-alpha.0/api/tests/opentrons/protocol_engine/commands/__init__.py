"""ProtocolEngine command model tests."""
