"""Tests module for ProtocolEngine state."""
