"""ProtocolEngine tests module."""
