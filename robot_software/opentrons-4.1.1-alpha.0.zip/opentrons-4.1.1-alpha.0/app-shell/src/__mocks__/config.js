// mock config
module.exports = jest.genMockFromModule('../config')
