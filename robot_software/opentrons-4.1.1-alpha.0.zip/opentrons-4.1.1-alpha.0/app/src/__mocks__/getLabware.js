// @flow
// TODO(mc, 2019-06-27): replace this mock with one in shared-data based on
// jest.fn and glob

export function getLegacyLabwareDef(loadName: ?string): null {
  return null
}

export function getLatestLabwareDef(loadName: ?string): null {
  return null
}
