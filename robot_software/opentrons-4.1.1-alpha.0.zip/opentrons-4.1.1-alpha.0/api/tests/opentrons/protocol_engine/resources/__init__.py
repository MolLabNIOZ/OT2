"""Tests module for ProtocolEngine resources."""
