"""Motion planning module tests."""
