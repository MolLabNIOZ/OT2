// mock logger
// NOTE: importing mock to avoid copy-paste
// eslint-disable-next-line jest/no-mocks-import
export * from '../../../app/src/__mocks__/logger'
