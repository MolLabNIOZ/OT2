// @flow
// os helpers

export const isWindows = (): boolean => process.platform === 'win32'
